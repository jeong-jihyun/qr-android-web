package com.example.qrscan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.core.content.ContextCompat

/**
 * Zebra DataWedge Intent API 헬퍼
 * - 프로필 자동 생성 (QR 인식 켜기 + 결과를 브로드캐스트 인텐트로 전달)
 * - 소프트 스캔 트리거
 * - 결과 수신
 */
object DataWedgeHelper {

    private const val DW_PACKAGE = "com.symbol.datawedge"
    private const val DW_ACTION = "com.symbol.datawedge.api.ACTION"

    const val PROFILE_NAME = "QrWebViewProfile"
    const val SCAN_ACTION = "com.example.qrscan.SCAN" // 본인 앱에 맞게 변경

    // 1) 프로필 생성/설정
    fun createProfile(ctx: Context) {
        // 바코드 입력 설정
        val barcodeParams = Bundle().apply {
            putString("scanner_selection", "auto")       // 기본 스캐너 자동 선택
            putString("scanner_input_enabled", "true")
            putString("decoder_qrcode", "true")           // QR 켜기
        }
        val barcodePlugin = Bundle().apply {
            putString("PLUGIN_NAME", "BARCODE")
            putString("RESET_CONFIG", "true")
            putBundle("PARAM_LIST", barcodeParams)
        }

        // 결과 출력: 우리 앱으로 브로드캐스트 인텐트 전달
        val intentParams = Bundle().apply {
            putString("intent_output_enabled", "true")
            putString("intent_action", SCAN_ACTION)
            putString("intent_delivery", "2")            // 2 = 브로드캐스트
        }
        val intentPlugin = Bundle().apply {
            putString("PLUGIN_NAME", "INTENT")
            putString("RESET_CONFIG", "true")
            putBundle("PARAM_LIST", intentParams)
        }

        // 이 프로필을 적용할 앱
        val appEntry = Bundle().apply {
            putString("PACKAGE_NAME", ctx.packageName)
            putStringArray("ACTIVITY_LIST", arrayOf("*"))
        }

        val profile = Bundle().apply {
            putString("PROFILE_NAME", PROFILE_NAME)
            putString("PROFILE_ENABLED", "true")
            putString("CONFIG_MODE", "CREATE_IF_NOT_EXIST")
            putParcelableArray("PLUGIN_CONFIG", arrayOf(barcodePlugin, intentPlugin))
            putParcelableArray("APP_LIST", arrayOf(appEntry))
        }

        sendCommand(ctx, "com.symbol.datawedge.api.SET_CONFIG", profile)
    }

    // 2) 화면 버튼으로 스캔 시작/중지 (소프트 트리거)
    fun startScan(ctx: Context) =
        sendCommand(ctx, "com.symbol.datawedge.api.SOFT_SCAN_TRIGGER", "START_SCANNING")

    fun stopScan(ctx: Context) =
        sendCommand(ctx, "com.symbol.datawedge.api.SOFT_SCAN_TRIGGER", "STOP_SCANNING")

    private fun sendCommand(ctx: Context, name: String, value: Bundle) {
        ctx.sendBroadcast(Intent(DW_ACTION).setPackage(DW_PACKAGE).putExtra(name, value))
    }

    private fun sendCommand(ctx: Context, name: String, value: String) {
        ctx.sendBroadcast(Intent(DW_ACTION).setPackage(DW_PACKAGE).putExtra(name, value))
    }

    // 3) 결과 수신
    fun registerReceiver(ctx: Context, onScan: (data: String, type: String) -> Unit): BroadcastReceiver {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val data = intent.getStringExtra("com.symbol.datawedge.data_string") ?: return
                val type = intent.getStringExtra("com.symbol.datawedge.label_type") ?: ""
                onScan(data, type)
            }
        }
        val filter = IntentFilter().apply {
            addAction(SCAN_ACTION)
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        return receiver
    }
}

/* ===== Activity 사용 예시 =====

class MainActivity : AppCompatActivity() {
    private var receiver: BroadcastReceiver? = null
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ... webView 설정 ...
        DataWedgeHelper.createProfile(this)
    }

    override fun onResume() {
        super.onResume()
        receiver = DataWedgeHelper.registerReceiver(this) { data, type ->
            // 웹으로 전달: 웹에서 window.onScan = (text, type) => { ... } 정의
            val js = "window.onScan && window.onScan(" +
                org.json.JSONObject.quote(data) + "," +
                org.json.JSONObject.quote(type) + ")"
            runOnUiThread { webView.evaluateJavascript(js, null) }
        }
    }

    override fun onPause() {
        super.onPause()
        receiver?.let { unregisterReceiver(it) }
    }
}

// 웹에서 버튼으로 스캔을 시작하고 싶다면 @JavascriptInterface로 startScan()을 노출하세요.
*/
