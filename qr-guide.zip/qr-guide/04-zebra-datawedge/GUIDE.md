# 4. Zebra DataWedge (Zebra 단말 전용)

## 한 줄 설명
Zebra 단말에 기본 설치된 스캔 서비스입니다. 앱이 카메라를 직접 다루지 않고, **DataWedge가 스캔한 결과를 인텐트로 받습니다.** 하드웨어 스캐너(레이저/이미저)와 카메라 스캔 모두 다룰 수 있습니다.

## 이 방법이 맞는 경우
- 대상이 **Zebra 단말**일 때
- 화면에 박스를 그리는 것보다 **빠르고 확실한 스캔**이 중요할 때
- 단말의 스캔 버튼(하드웨어 트리거)을 그대로 쓰고 싶을 때

## 동작 원리 (생각의 흐름)
1. 앱이 시작될 때 DataWedge에 "프로필 만들어 달라"는 명령을 보냅니다. (QR 켜기 + 결과를 우리 앱으로 보내기)
2. 사용자가 스캔 버튼을 누르거나 앱이 소프트 트리거를 보냅니다.
3. DataWedge가 스캔하고, 결과를 **브로드캐스트 인텐트**로 보냅니다.
4. 앱의 리시버가 결과(`data_string`)를 받아 웹뷰의 JS로 전달합니다.

## 사용법
1. `DataWedgeHelper.kt`를 프로젝트에 복사합니다. (`SCAN_ACTION`, 패키지명은 본인 앱에 맞게 변경)
2. `onCreate`에서 `DataWedgeHelper.createProfile(this)`
3. `onResume`에서 리시버 등록, `onPause`에서 해제 (파일 아래 주석의 예시 참고)
4. 웹에서는 `window.onScan = (text, type) => {...}`를 정의해 결과를 받습니다.

## 프로필을 앱 코드 대신 수동으로 만들 수도 있습니다
단말의 DataWedge 앱에서 프로필을 만들고 다음을 설정해도 됩니다.
- 연결 앱: 본인 앱 패키지
- Barcode input: Enabled, QR Code 선택
- Intent output: Enabled, Action = `com.example.qrscan.SCAN`, Delivery = Broadcast intent
- Keystroke output: 끄기 (켜져 있으면 키 입력으로 이중 입력될 수 있음)

## 다중 QR / 위치 표시에 대해 (중요)
- **제가 확인하지 못한 부분입니다.** DataWedge의 다중 바코드 스캔 설정과 결과 형식은 **DataWedge 버전과 단말 모델에 따라 다릅니다.**
- 이 샘플은 "QR 하나를 스캔해 결과를 받는" 기본 흐름만 포함합니다.
- 다중 바코드가 필요하면 Zebra 공식 문서(DataWedge Intent API, Multi-Barcode 항목)에서 대상 단말 버전의 지원 여부와 파라미터를 확인하세요.
- DataWedge는 **내 화면에 박스를 그려주는 용도가 아닙니다.** 박스 표시가 필요하면 3번(ML Kit)을 쓰세요.

## 한계 / 주의
- Zebra 단말에서만 동작합니다. (일반 안드로이드폰에는 DataWedge가 없습니다.)
- 안드로이드 13 이상에서는 리시버 등록 시 `RECEIVER_EXPORTED` 플래그가 필요합니다. (샘플에 반영됨)
- 키 입력 출력(Keystroke output)이 켜져 있으면 결과가 중복으로 들어올 수 있습니다.
- 이 샘플은 제가 실제 Zebra 단말에서 실행해 보지 못했습니다.

## 체크리스트
- [ ] 단말에 DataWedge가 설치/활성화되어 있는가
- [ ] 프로필이 생성되어 우리 앱에 연결되었는가
- [ ] 스캔 시 리시버로 결과가 들어오는가
- [ ] 결과가 웹뷰의 `window.onScan`까지 전달되는가
- [ ] Keystroke output 때문에 중복 입력되지 않는가
