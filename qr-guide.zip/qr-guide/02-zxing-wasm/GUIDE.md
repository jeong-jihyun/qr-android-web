# 2. zxing-wasm (JS 라이브러리)

## 한 줄 설명
유명한 ZXing 인식 엔진을 WebAssembly로 만든 라이브러리입니다. 브라우저 내장 기능(BarcodeDetector)이 없는 환경에서도 **여러 QR + 위치 좌표**를 얻을 수 있습니다.

## 이 방법이 맞는 경우
- 앱(네이티브) 코드를 건드릴 수 없고
- 웹뷰에서 BarcodeDetector가 지원되지 않을 때
- 브라우저/단말 차이 없이 같은 동작이 필요할 때

## 동작 원리 (생각의 흐름)
1. 카메라 영상을 `<video>`에 띄웁니다. (1번과 동일)
2. 인식할 때마다 영상 한 장을 **작은 캔버스(최대 가로 960px)**에 복사합니다. (작을수록 빠름)
3. 그 이미지 데이터를 `readBarcodes()`에 넣어 QR 목록을 받습니다.
4. 각 결과의 4개 모서리 좌표를 원래 영상 크기로 환산해 캔버스에 박스를 그립니다.
5. 이전 인식이 끝나기 전에는 다음 인식을 시작하지 않습니다(`busy`). 단말이 밀리지 않게 하기 위함입니다.

## 설치와 사용
```bash
npm install zxing-wasm
```
```jsx
import ZxingScanner from "./ZxingScanner";

<ZxingScanner onSelect={(text) => console.log("선택:", text)} />
```

## wasm 파일 로딩 (웹뷰에서 가장 중요)
라이브러리는 기본적으로 wasm 파일을 인터넷(CDN)에서 내려받습니다. 현장 단말이 **오프라인이거나 사내망**이면 실패할 수 있습니다.

샘플은 Vite 기준으로 wasm 파일을 앱에 포함시킵니다.
```js
import wasmUrl from "zxing-wasm/reader/zxing_reader.wasm?url";
prepareZXingModule({
  overrides: { locateFile: (path, prefix) => path.endsWith(".wasm") ? wasmUrl : prefix + path },
  fireImmediately: true,
});
```
- 다른 번들러(CRA, webpack 등)는 wasm을 정적 파일로 복사하고 그 주소를 `locateFile`에 반환하면 됩니다.
- **패키지 버전에 따라 import 경로와 옵션 이름이 다를 수 있으니**, 설치한 버전의 공식 README와 한 번 대조해 보세요. (저는 설치된 버전을 확인하지 못했습니다.)

## 성능 조절
| 조절 항목 | 효과 |
|---|---|
| `MAX_W` (인식 이미지 가로폭) | 줄이면 빠르지만 작은 QR을 놓칠 수 있음 |
| `setTimeout(loop, 150)` 간격 | 늘리면 발열/배터리 절약 |
| `maxNumberOfSymbols` | 한 화면에서 찾을 최대 QR 수 |
| `tryHarder` | 켜면 정확하지만 느림 |

## 한계 / 주의
- 영상에서 매번 이미지를 뽑아 분석하므로 **네이티브(3번)보다 느리고 발열이 있을 수 있습니다.**
- 웹뷰의 WebAssembly 지원은 최신 Chromium 기반이면 대체로 되지만, 구형 단말은 대상 단말에서 확인이 필요합니다.
- 줌/초점 제어는 1번과 동일하게 단말 지원에 따라 다릅니다.

## 체크리스트
- [ ] wasm 파일이 앱에 포함되어 오프라인에서도 로딩되는가
- [ ] QR 2개 이상을 동시에 비추었을 때 각각 박스가 표시되는가
- [ ] 단말 발열/속도가 현장에서 허용 가능한가 (`MAX_W`, 간격 조절)
