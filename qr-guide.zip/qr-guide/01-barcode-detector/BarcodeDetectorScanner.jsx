import { useEffect, useRef, useState } from "react";

// 점이 4각형 안에 있는지 검사 (터치한 QR 찾기용)
const inPolygon = (pt, poly) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y;
    const xj = poly[j].x, yj = poly[j].y;
    if (yi > pt.y !== yj > pt.y && pt.x < ((xj - xi) * (pt.y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
};

export default function BarcodeDetectorScanner({ onSelect }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const trackRef = useRef(null);
  const codesRef = useRef([]); // 최신 인식 결과 (화면 갱신 없이 보관)

  const [supported, setSupported] = useState(true);
  const [error, setError] = useState("");
  const [list, setList] = useState([]);
  const [selected, setSelected] = useState("");
  const [caps, setCaps] = useState({});
  const [zoom, setZoom] = useState(1);
  const [focusMode, setFocusMode] = useState("");

  // 인식된 QR마다 테두리와 번호를 그림
  const draw = (found) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = Math.max(3, canvas.width / 200);
    ctx.font = `bold ${Math.max(18, canvas.width / 35)}px sans-serif`;
    ctx.strokeStyle = "#00e676";
    ctx.fillStyle = "#00e676";
    found.forEach((c, i) => {
      const p = c.cornerPoints;
      ctx.beginPath();
      ctx.moveTo(p[0].x, p[0].y);
      p.slice(1).forEach((q) => ctx.lineTo(q.x, q.y));
      ctx.closePath();
      ctx.stroke();
      ctx.fillText(String(i + 1), p[0].x, p[0].y - 8);
    });
  };

  useEffect(() => {
    if (!("BarcodeDetector" in window)) {
      setSupported(false);
      return;
    }
    let stopped = false;
    let timer = null;
    let stream = null;
    const detector = new window.BarcodeDetector({ formats: ["qr_code"] });

    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
        if (stopped) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        const video = videoRef.current;
        video.srcObject = stream;
        await video.play();

        const track = stream.getVideoTracks()[0];
        trackRef.current = track;
        const c = track.getCapabilities ? track.getCapabilities() : {};
        const s = track.getSettings ? track.getSettings() : {};
        setCaps(c);
        if (c.zoom) setZoom(s.zoom ?? c.zoom.min);
        if (c.focusMode) setFocusMode(s.focusMode || c.focusMode[0]);

        // 약 8번/초 인식 (너무 자주 하면 단말이 느려짐)
        const loop = async () => {
          if (stopped) return;
          try {
            if (video.readyState >= 2) {
              const found = await detector.detect(video);
              codesRef.current = found;
              draw(found);
              setList(found.map((f) => f.rawValue));
            }
          } catch (e) {
            /* 프레임 한두 개 실패는 무시 */
          }
          timer = setTimeout(loop, 120);
        };
        loop();
      } catch (e) {
        setError(`${e.name}: ${e.message}`);
      }
    })();

    return () => {
      stopped = true;
      clearTimeout(timer);
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const apply = async (constraint) => {
    try {
      await trackRef.current?.applyConstraints({ advanced: [constraint] });
    } catch (e) {
      console.warn("적용 실패", e);
    }
  };

  // 화면 터치: 터치한 QR 선택 + 그 위치로 초점 시도
  const onTap = (e) => {
    const video = videoRef.current;
    if (!video) return;
    const rect = video.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    const pt = { x: nx * video.videoWidth, y: ny * video.videoHeight };

    const hit = codesRef.current.find((c) => inPolygon(pt, c.cornerPoints));
    if (hit) {
      setSelected(hit.rawValue);
      onSelect && onSelect(hit.rawValue);
    }

    if (caps.pointsOfInterest) {
      apply({ pointsOfInterest: [{ x: nx, y: ny }], focusMode: "single-shot" });
    } else if ((caps.focusMode || []).includes("single-shot")) {
      apply({ focusMode: "single-shot" });
    }
    setTimeout(() => {
      if ((caps.focusMode || []).includes("continuous")) {
        apply({ focusMode: "continuous" });
        setFocusMode("continuous");
      }
    }, 1500);
  };

  if (!supported) {
    return <p>이 브라우저/웹뷰는 BarcodeDetector를 지원하지 않습니다. (2번 zxing-wasm 사용)</p>;
  }

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", padding: 12, fontFamily: "sans-serif" }}>
      <div style={{ position: "relative" }} onClick={onTap}>
        <video
          ref={videoRef}
          muted
          playsInline
          style={{ width: "100%", display: "block", background: "#000" }}
        />
        <canvas
          ref={canvasRef}
          style={{
            position: "absolute", top: 0, left: 0,
            width: "100%", height: "100%", pointerEvents: "none",
          }}
        />
      </div>

      {caps.zoom && (
        <div style={{ margin: "10px 0" }}>
          <label>확대: {Number(zoom).toFixed(1)}x</label>
          <input
            type="range" style={{ width: "100%" }}
            min={caps.zoom.min} max={caps.zoom.max} step={caps.zoom.step || 0.1}
            value={zoom}
            onChange={(e) => {
              setZoom(Number(e.target.value));
              apply({ zoom: Number(e.target.value) });
            }}
          />
        </div>
      )}

      {caps.focusMode && (
        <div style={{ margin: "10px 0" }}>
          <label>초점 모드</label>
          <select
            style={{ width: "100%", padding: 8 }}
            value={focusMode}
            onChange={(e) => {
              setFocusMode(e.target.value);
              apply({ focusMode: e.target.value });
            }}
          >
            {caps.focusMode.map((m) => <option key={m}>{m}</option>)}
          </select>
        </div>
      )}

      {error && <p style={{ color: "red" }}>{error}</p>}

      <h4>화면에 인식된 QR ({list.length}개)</h4>
      <ol>{list.map((v, i) => <li key={i} style={{ wordBreak: "break-all" }}>{v}</li>)}</ol>
      <h4>선택한 QR</h4>
      <div style={{ padding: 10, background: "#eef", borderRadius: 6, wordBreak: "break-all" }}>
        {selected || "- (박스를 터치하면 선택됩니다)"}
      </div>
    </div>
  );
}
