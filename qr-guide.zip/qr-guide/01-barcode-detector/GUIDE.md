# 1. BarcodeDetector (브라우저 내장 기능)

## 한 줄 설명
브라우저에 이미 들어 있는 바코드 인식 기능입니다. **설치할 라이브러리가 없고**, 화면의 여러 QR을 한 번에 읽으며 각 QR의 **4개 모서리 좌표**를 줍니다.

## 이 방법이 맞는 경우
- 앱(네이티브) 코드를 건드릴 수 없을 때
- 용량을 늘리기 싫을 때
- 대상 단말 웹뷰에서 지원이 확인되었을 때

## 동작 원리 (생각의 흐름)
1. `getUserMedia`로 카메라 영상을 `<video>`에 띄웁니다.
2. 약 0.12초마다 `detector.detect(video)`를 호출합니다.
3. 결과로 `rawValue`(QR 내용)와 `cornerPoints`(4점)를 받습니다.
4. `<video>` 위에 겹친 `<canvas>`에 4점을 이어 테두리를 그립니다.
5. 화면을 터치하면 터치 좌표가 어느 QR 사각형 안인지 계산해 선택합니다.
6. 줌/초점은 카메라 트랙(`applyConstraints`)으로 조절합니다.

## 사용법
```jsx
import BarcodeDetectorScanner from "./BarcodeDetectorScanner";

<BarcodeDetectorScanner onSelect={(text) => console.log("선택:", text)} />
```
설치 필요한 패키지는 없습니다.

## 단말에서 지원 확인
```js
"BarcodeDetector" in window
  ? await BarcodeDetector.getSupportedFormats() // 결과에 "qr_code"가 있어야 함
  : "미지원"
```

## 웹뷰 설정 (안드로이드 앱 쪽)
웹뷰는 앱이 카메라 권한을 열어줘야 합니다.

- `AndroidManifest.xml`: `<uses-permission android:name="android.permission.CAMERA" />`
- `WebView.settings`: `javaScriptEnabled = true`, `mediaPlaybackRequiresUserGesture = false`
- `WebChromeClient.onPermissionRequest`에서 카메라 권한이 있으면 `request.grant(request.resources)`
- 개발 중 확인: `WebView.setWebContentsDebuggingEnabled(true)` 후 PC Chrome `chrome://inspect`

## 한계 / 주의
- 웹뷰(WebView) 지원 여부는 **단말과 Chromium 버전에 따라 다릅니다.** 반드시 대상 단말에서 확인하세요.
- iOS Safari는 지원하지 않습니다.
- 지원되지 않으면 이 컴포넌트가 안내 문구를 보여줍니다 → **2번(zxing-wasm)** 으로 전환하세요.
- 줌/초점 제어도 단말마다 지원이 다릅니다.

## 체크리스트
- [ ] HTTPS 또는 localhost로 접속했는가
- [ ] 웹뷰 카메라 권한 처리를 했는가
- [ ] `BarcodeDetector.getSupportedFormats()` 결과에 `qr_code`가 있는가
- [ ] QR 2개 이상을 동시에 비추어 박스가 각각 표시되는가
