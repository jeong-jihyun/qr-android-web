package com.example.qrscan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** 인식된 QR 하나 (box는 "이미지 좌표" 기준) */
data class Detected(val box: RectF, val value: String)

/**
 * 카메라 미리보기 위에 겹쳐서 QR 박스를 그리는 뷰.
 * 이미지 좌표 -> 화면 좌표 변환은 PreviewView의 FILL_CENTER 방식과 동일하게 계산합니다.
 */
class OverlayView(context: Context) : View(context) {

    private var items: List<Detected> = emptyList()
    private var imgW = 1
    private var imgH = 1

    /** 터치 콜백: (화면 x, 화면 y, 터치한 QR 또는 null) */
    var onTap: ((Float, Float, Detected?) -> Unit)? = null

    private val boxPaint = Paint().apply {
        color = Color.parseColor("#00E676")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val textPaint = Paint().apply {
        color = Color.parseColor("#00E676")
        textSize = 48f
        isFakeBoldText = true
    }

    fun update(newItems: List<Detected>, w: Int, h: Int) {
        items = newItems
        imgW = w
        imgH = h
        invalidate()
    }

    // 이미지 좌표 -> 화면 좌표 (FILL_CENTER: 화면을 가득 채우고 넘치는 부분은 잘림)
    private fun toView(r: RectF): RectF {
        val scale = max(width.toFloat() / imgW, height.toFloat() / imgH)
        val dx = (width - imgW * scale) / 2f
        val dy = (height - imgH * scale) / 2f
        return RectF(r.left * scale + dx, r.top * scale + dy, r.right * scale + dx, r.bottom * scale + dy)
    }

    override fun onDraw(canvas: Canvas) {
        items.forEachIndexed { i, d ->
            val r = toView(d.box)
            canvas.drawRect(r, boxPaint)
            canvas.drawText("${i + 1}", r.left, r.top - 10f, textPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val hit = items.firstOrNull { toView(it.box).contains(e.x, e.y) }
            onTap?.invoke(e.x, e.y, hit)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
