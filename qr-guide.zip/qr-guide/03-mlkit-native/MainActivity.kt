package com.example.qrscan

import android.Manifest
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * ML Kit + CameraX: 여러 QR 인식, 박스 표시, 줌, 터치 초점
 * 화면은 코드로 만들었습니다 (XML 불필요).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var zoomBar: SeekBar

    private var camera: Camera? = null
    private val analysisExecutor = Executors.newSingleThreadExecutor()

    // QR만 인식하도록 설정 (속도 향상)
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
    )

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else Toast.makeText(this, "카메라 권한이 필요합니다", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = FrameLayout(this)

        previewView = PreviewView(this).apply {
            // 아래 OverlayView의 좌표 계산은 FILL_CENTER 기준입니다
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        overlay = OverlayView(this).apply {
            onTap = { x, y, hit -> handleTap(x, y, hit) }
        }
        zoomBar = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) camera?.cameraControl?.setLinearZoom(p / 100f)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

        root.addView(previewView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(overlay, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(
            zoomBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { gravity = Gravity.BOTTOM; setMargins(48, 0, 48, 96) }
        )
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // 밀리면 이전 프레임 버림
                .build()
                .also { it.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy) } }

            provider.unbindAll()
            camera = provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) { proxy.close(); return }

        val rotation = proxy.imageInfo.rotationDegrees
        // ML Kit 좌표는 "회전을 적용한 똑바른 이미지" 기준입니다
        val imgW = if (rotation == 90 || rotation == 270) proxy.height else proxy.width
        val imgH = if (rotation == 90 || rotation == 270) proxy.width else proxy.height

        scanner.process(InputImage.fromMediaImage(media, rotation))
            .addOnSuccessListener { list ->
                val items = list.mapNotNull { b ->
                    b.boundingBox?.let { box ->
                        Detected(RectF(box), b.rawValue ?: "")
                    }
                }
                runOnUiThread { overlay.update(items, imgW, imgH) }
            }
            .addOnCompleteListener { proxy.close() } // 반드시 닫아야 다음 프레임이 옴
    }

    // 화면 터치: 그 위치로 초점 + (QR 박스를 눌렀다면) 선택
    private fun handleTap(x: Float, y: Float, hit: Detected?) {
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point).build()
        camera?.cameraControl?.startFocusAndMetering(action)

        if (hit != null) {
            Toast.makeText(this, "선택: ${hit.value}", Toast.LENGTH_SHORT).show()
            // 웹뷰로 전달하려면 아래처럼 호출 (webView가 있을 때)
            // webView.evaluateJavascript("window.onNativeQr(" + org.json.JSONObject.quote(hit.value) + ")", null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
        scanner.close()
    }
}
