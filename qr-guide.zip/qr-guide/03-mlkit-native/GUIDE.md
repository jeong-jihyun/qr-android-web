# 3. ML Kit + CameraX (안드로이드 네이티브)

## 한 줄 설명
구글 ML Kit 바코드 스캐너로 **여러 QR을 인식하고 위치(박스)를 표시**합니다. 카메라는 CameraX로 다룹니다. 네 가지 중 **가장 안정적이고 빠른 방법**입니다.

## 이 방법이 맞는 경우
- 안드로이드 앱 코드를 수정할 수 있을 때
- 웹뷰 지원 여부와 상관없이 확실하게 동작해야 할 때
- 줌/터치 초점 같은 카메라 제어를 안정적으로 쓰고 싶을 때

## 동작 원리 (생각의 흐름)
1. CameraX가 카메라 영상을 두 곳으로 보냅니다: 화면 미리보기(`Preview`)와 분석용(`ImageAnalysis`).
2. 분석용 프레임을 ML Kit에 넣으면 QR 목록과 각 QR의 `boundingBox`를 줍니다.
3. `OverlayView`가 그 박스를 화면 좌표로 바꿔 미리보기 위에 그립니다.
4. 좌표 변환이 어려운 이유: 카메라 이미지는 회전되어 있고, 미리보기는 화면을 가득 채우며 잘립니다. 그래서 `rotationDegrees`로 가로/세로를 맞추고 `FILL_CENTER` 계산식으로 변환합니다.
5. 줌은 `setLinearZoom`, 초점은 터치 위치로 `startFocusAndMetering`을 호출합니다.
6. 분석이 끝나면 `proxy.close()`를 꼭 호출해야 다음 프레임이 들어옵니다.

## 준비

`app/build.gradle.kts`
```kotlin
dependencies {
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
}
```
(버전은 예시입니다. 최신 안정 버전을 확인해서 사용하세요.)

`AndroidManifest.xml`
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

## 사용법
1. `MainActivity.kt`, `OverlayView.kt`를 프로젝트 패키지에 복사합니다. (`package com.example.qrscan`은 본인 패키지로 변경)
2. 앱 실행 → 카메라 권한 허용 → QR 여러 개를 비춥니다.
3. 박스를 터치하면 선택(토스트)되고 그 위치로 초점을 맞춥니다.
4. 아래 슬라이더로 줌을 조절합니다.

## 웹뷰로 결과 넘기기
`handleTap` 안의 주석을 풀면 JS의 `window.onNativeQr(값)`을 호출합니다.
```js
window.onNativeQr = (text) => { /* 웹 화면에서 처리 */ };
```
웹뷰 안에서 이 화면을 띄우려면 이 Activity를 별도 화면으로 열고(`startActivityForResult` 또는 Activity Result API), 선택값을 웹뷰로 돌려주는 구조를 권장합니다.

## 한계 / 주의
- 박스 위치는 `PreviewView`가 `FILL_CENTER`일 때 맞습니다. 다른 `scaleType`을 쓰면 `OverlayView.toView()`도 바꿔야 합니다.
- ML Kit의 번들 모델은 앱 용량이 조금 늘어납니다. (Google Play 서비스 기반 버전도 있으나, 구글 서비스가 없는 단말은 번들 버전이 안전합니다.)
- 이 샘플은 제가 실제 단말에서 실행해 보지 못했습니다. 박스가 어긋나면 `rotationDegrees`와 `scaleType`부터 확인하세요.

## 체크리스트
- [ ] 카메라 권한 허용 후 미리보기가 나오는가
- [ ] QR 여러 개에 박스가 각각 표시되는가
- [ ] 박스 위치가 QR과 어긋나지 않는가 (세로/가로 모드 모두)
- [ ] 줌 슬라이더와 터치 초점이 동작하는가
