// useScannerInput.js
//
// USB, USB-C 케이블, 블루투스로 연결된 Zebra 스캐너는 대부분
// "키보드 웨지(HID Keyboard Emulation)" 모드로 동작합니다.
// 즉 스캔을 하면 마치 사람이 키보드로 빠르게 타이핑하고 Enter를 누른 것처럼
// 브라우저에 문자 입력 이벤트가 들어옵니다.
//
// 이 훅은 문서 전체에서 키 입력을 감지하다가,
// "짧은 시간 안에 여러 글자가 들어오고 Enter로 끝나는" 패턴을 스캔으로 판단합니다.
// 사람이 직접 타이핑하는 속도(보통 글자당 100ms 이상)보다
// 스캐너 입력 속도가 훨씬 빠르다는 점(글자당 수~수십 ms)을 이용합니다.

import { useEffect, useRef } from "react";

// 이 값보다 빠르게 연속 입력되면 "스캐너 입력"으로 간주 (ms)
const SCAN_CHAR_INTERVAL_MS = 50;
// 최소 이 글자 수 이상이어야 스캔으로 인정 (오탐 방지)
const MIN_SCAN_LENGTH = 3;

/**
 * @param {function} onScan - 스캔이 감지되었을 때 호출되는 콜백 (data: string) => void
 * @param {boolean} enabled - 스캔 감지를 켜고 끌 수 있는 플래그 (기본 true)
 */
function useScannerInput(onScan, enabled = true) {
  const bufferRef = useRef("");
  const lastCharTimeRef = useRef(0);

  useEffect(() => {
    if (!enabled) return;

    function handleKeyDown(event) {
      const now = Date.now();
      const elapsed = now - lastCharTimeRef.current;

      // 입력창(input, textarea)에 포커스가 가 있어도 동작하도록 별도 처리는 하지 않음.
      // 스캐너는 실제 포커스된 요소에 키 이벤트를 그대로 흘려보내기 때문에
      // window 레벨에서 캡처링 방식으로 먼저 가로채는 것이 안전합니다.

      if (event.key === "Enter") {
        // Enter가 눌렸을 때 버퍼에 쌓인 내용이 스캔 조건을 만족하는지 확인
        if (bufferRef.current.length >= MIN_SCAN_LENGTH) {
          onScan(bufferRef.current);
        }
        bufferRef.current = "";
        return;
      }

      // 일반 문자 키가 아니면(Shift, Ctrl 등) 무시
      if (event.key.length !== 1) return;

      if (elapsed > SCAN_CHAR_INTERVAL_MS && bufferRef.current.length > 0) {
        // 너무 느리게 들어온 입력 = 사람이 타이핑 중인 것으로 보고 버퍼 초기화
        bufferRef.current = "";
      }

      bufferRef.current += event.key;
      lastCharTimeRef.current = now;
    }

    // capture: true 로 등록해서 다른 입력 요소보다 먼저 이벤트를 관찰
    window.addEventListener("keydown", handleKeyDown, true);

    return () => {
      window.removeEventListener("keydown", handleKeyDown, true);
    };
  }, [onScan, enabled]);
}

export default useScannerInput;
