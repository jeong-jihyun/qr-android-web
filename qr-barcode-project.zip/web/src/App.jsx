// App.jsx
// ScanPanel(스캔 감지)과 LabelPrinter(생성/출력)를 연결합니다.
// 스캔이 감지되면 LabelPrinter의 입력값을 자동으로 채웁니다.

import React from "react";
import ScanPanel from "./components/ScanPanel";
import LabelPrinter from "./components/LabelPrinter";

function App() {
  // LabelPrinter 내부 상태를 외부에서 채우기 위해 ref 사용
  const labelPrinterRef = React.useRef(null);

  const handleScan = (scannedValue) => {
    if (labelPrinterRef.current) {
      labelPrinterRef.current.setValue(scannedValue);
    }
  };

  return (
    <div style={{ padding: 24 }}>
      <h1>QR/바코드 라벨 시스템 (Web)</h1>

      {/* 스캐너로 스캔하면 handleScan이 호출되어 아래 LabelPrinter 입력값이 자동으로 채워짐 */}
      <ScanPanel onScan={handleScan} />

      <LabelPrinter ref={labelPrinterRef} />
    </div>
  );
}

export default App;
