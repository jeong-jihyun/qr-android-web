// QrCodeGenerator.jsx
// QR코드를 생성해서 화면에 보여주는 컴포넌트입니다.
// 사용 라이브러리: qrcode.react (React 16.13.1과 호환되는 1.x 버전 사용 권장)
//   - 폐쇄망 환경이라면 npm pack으로 tgz 파일을 받아 로컬 설치하세요.

import React from "react";
import QRCode from "qrcode.react";

/**
 * QR코드 생성 컴포넌트
 * @param {string} value - QR코드로 변환할 문자열 (예: Work Order 번호, 자재 코드 등)
 * @param {number} size - QR코드 크기(px), 기본 180
 */
function QrCodeGenerator({ value, size = 180 }) {
  if (!value) {
    return <div style={{ color: "#999" }}>QR코드로 변환할 값을 입력하세요.</div>;
  }

  return (
    <div className="qr-code-wrapper">
      {/* renderAs="canvas"로 지정해야 이후 canvas.toDataURL()로 이미지 추출이 가능합니다 */}
      <QRCode value={value} size={size} level="M" renderAs="canvas" />
    </div>
  );
}

export default QrCodeGenerator;
