// ScanPanel.jsx
// USB/C-Type/블루투스 스캐너로 스캔한 값을 감지해서 화면에 보여주는 패널입니다.
// 내부적으로 useScannerInput 훅을 사용합니다.

import React from "react";
import useScannerInput from "../hooks/useScannerInput";

/**
 * @param {function} onScan - 스캔값이 감지될 때마다 호출되는 콜백 (예: LabelPrinter 입력값 채우기)
 */
function ScanPanel({ onScan }) {
  const [lastScanned, setLastScanned] = React.useState("");
  const [scanCount, setScanCount] = React.useState(0);

  const handleScan = React.useCallback(
    (data) => {
      setLastScanned(data);
      setScanCount((count) => count + 1);
      if (onScan) onScan(data);
    },
    [onScan]
  );

  useScannerInput(handleScan, true);

  return (
    <div style={{ border: "1px solid #ddd", padding: 12, marginBottom: 16 }}>
      <h3>스캐너 입력 대기 중</h3>
      <p style={{ color: "#666", fontSize: 13 }}>
        USB, C-Type, 블루투스로 연결된 스캐너로 QR/바코드를 스캔하면 아래에 표시됩니다.
        (스캐너가 키보드 웨지 모드인지 먼저 확인하세요)
      </p>
      <p>
        마지막 스캔값: <strong>{lastScanned || "-"}</strong>
      </p>
      <p style={{ fontSize: 12, color: "#999" }}>누적 스캔 횟수: {scanCount}</p>
    </div>
  );
}

export default ScanPanel;
