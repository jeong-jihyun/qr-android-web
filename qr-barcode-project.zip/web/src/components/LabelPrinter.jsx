// LabelPrinter.jsx
// QR코드/바코드 미리보기 + Zebra 프린터로 라벨 출력까지 담당하는 통합 컴포넌트
// (web 전용: Browser Print를 통해 출력)

import React from "react";
import QrCodeGenerator from "./QrCodeGenerator";
import BarcodeGenerator from "./BarcodeGenerator";
import {
  getDefaultPrinter,
  printZpl,
  buildQrLabelZpl,
  buildBarcodeLabelZpl,
} from "../services/browserPrintService";

// forwardRef로 감싸서 상위(App)에서 스캔값을 이 컴포넌트의 입력값으로 채울 수 있게 함
const LabelPrinter = React.forwardRef(function LabelPrinter(_props, ref) {
  const [inputValue, setInputValue] = React.useState("");
  const [labelType, setLabelType] = React.useState("qr");
  const [statusMessage, setStatusMessage] = React.useState("");

  // 상위 컴포넌트(App)가 ref.current.setValue(...) 형태로 값을 채울 수 있도록 노출
  React.useImperativeHandle(ref, () => ({
    setValue: (value) => setInputValue(value),
  }));

  const handlePrint = async () => {
    if (!inputValue) {
      setStatusMessage("먼저 값을 입력하세요.");
      return;
    }

    setStatusMessage("프린터 연결 중...");

    try {
      const printer = await getDefaultPrinter();

      const zpl =
        labelType === "qr"
          ? buildQrLabelZpl(inputValue, "QR Label")
          : buildBarcodeLabelZpl(inputValue, "Barcode Label");

      setStatusMessage("출력 요청 중...");
      await printZpl(printer, zpl);

      setStatusMessage("출력 완료");
    } catch (err) {
      setStatusMessage("오류: " + err.message);
    }
  };

  return (
    <div style={{ maxWidth: 360 }}>
      <h3>라벨 생성 및 출력</h3>

      <input
        type="text"
        placeholder="Work Order 번호 등 입력 (스캔 시 자동 입력됨)"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        style={{ width: "100%", marginBottom: 8 }}
      />

      <div style={{ marginBottom: 8 }}>
        <label>
          <input
            type="radio"
            checked={labelType === "qr"}
            onChange={() => setLabelType("qr")}
          />
          QR코드
        </label>
        <label style={{ marginLeft: 12 }}>
          <input
            type="radio"
            checked={labelType === "barcode"}
            onChange={() => setLabelType("barcode")}
          />
          바코드
        </label>
      </div>

      <div style={{ marginBottom: 12 }}>
        {labelType === "qr" ? (
          <QrCodeGenerator value={inputValue} />
        ) : (
          <BarcodeGenerator value={inputValue} />
        )}
      </div>

      <button onClick={handlePrint}>라벨 출력</button>

      {statusMessage && <p style={{ marginTop: 8 }}>{statusMessage}</p>}
    </div>
  );
});

export default LabelPrinter;
