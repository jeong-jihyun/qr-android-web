// BarcodeGenerator.jsx
// 1차원 바코드(CODE128 등)를 생성해서 화면에 보여주는 컴포넌트입니다.
// 사용 라이브러리: jsbarcode (React 버전에 의존하지 않아 안전하게 사용 가능)

import React from "react";
import JsBarcode from "jsbarcode";

/**
 * 바코드 생성 컴포넌트
 * @param {string} value - 바코드로 변환할 문자열
 * @param {string} format - 바코드 형식 (기본 CODE128)
 * @param {number} height - 바코드 높이(px)
 */
function BarcodeGenerator({ value, format = "CODE128", height = 60 }) {
  const svgRef = React.useRef(null);

  React.useEffect(() => {
    if (!value || !svgRef.current) return;

    try {
      JsBarcode(svgRef.current, value, {
        format: format,
        height: height,
        displayValue: true, // 바코드 하단에 텍스트 값도 함께 표시
        margin: 8,
      });
    } catch (err) {
      // 잘못된 값(예: EAN13인데 자릿수가 안 맞는 경우) 등 예외 처리
      console.error("바코드 생성 실패:", err.message);
    }
  }, [value, format, height]);

  if (!value) {
    return <div style={{ color: "#999" }}>바코드로 변환할 값을 입력하세요.</div>;
  }

  return <svg ref={svgRef} className="barcode-svg" />;
}

export default BarcodeGenerator;
