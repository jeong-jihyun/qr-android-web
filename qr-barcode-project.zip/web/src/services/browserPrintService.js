// browserPrintService.js
// Zebra Browser Print 로컬 에이전트와 통신하는 서비스 모듈입니다.
// (이 파일은 브라우저에서 직접 실행되는 web 프로젝트 전용입니다.
//  webview-app에서는 대신 androidBridgeService.js를 사용합니다.)
//
// 사전 준비:
// 1) 프린터를 사용할 PC마다 "Zebra Browser Print" 에이전트 프로그램을 설치해야 합니다.
// 2) BrowserPrint JS SDK 파일을 반입해서 public/vendor/BrowserPrint-3.x.js 에 두고
//    index.html에서 <script> 태그로 로드하세요.

function ensureSdkLoaded() {
  if (typeof window === "undefined" || !window.BrowserPrint) {
    throw new Error(
      "BrowserPrint SDK를 찾을 수 없습니다. index.html에 스크립트가 로드되었는지, " +
        "Zebra Browser Print 에이전트가 PC에 설치/실행 중인지 확인하세요."
    );
  }
}

/**
 * 시스템에 연결된 기본 프린터(디바이스)를 조회합니다.
 */
export function getDefaultPrinter() {
  return new Promise((resolve, reject) => {
    ensureSdkLoaded();

    window.BrowserPrint.getDefaultDevice(
      "printer",
      (device) => {
        if (!device) {
          reject(new Error("연결된 기본 프린터를 찾을 수 없습니다."));
          return;
        }
        resolve(device);
      },
      (err) => reject(new Error("프린터 탐색 중 오류: " + err))
    );
  });
}

/**
 * 지정한 프린터로 ZPL 문자열을 전송해 라벨을 출력합니다.
 */
export function printZpl(device, zpl) {
  return new Promise((resolve, reject) => {
    if (!device) {
      reject(new Error("프린터 디바이스가 지정되지 않았습니다."));
      return;
    }

    device.send(
      zpl,
      () => resolve(true),
      (err) => reject(new Error("출력 실패: " + err))
    );
  });
}

/**
 * QR코드용 ZPL 라벨 문자열을 생성하는 헬퍼 함수
 * (실제 좌표/크기는 사용 중인 라벨 용지 규격에 맞게 조정 필요)
 */
export function buildQrLabelZpl(value, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BQN,2,6
^FDQA,${value}^FS
^XZ
  `.trim();
}

/**
 * CODE128 바코드용 ZPL 라벨 문자열을 생성하는 헬퍼 함수
 */
export function buildBarcodeLabelZpl(value, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BY2
^BCN,80,Y,N,N
^FD${value}^FS
^XZ
  `.trim();
}
