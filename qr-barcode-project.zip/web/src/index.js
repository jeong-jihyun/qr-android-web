// index.js
// React 16.13.1 에서는 ReactDOM.render 방식을 사용합니다.

import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById("root")
);
