# QR/바코드 생성 · 스캔 · 라벨 출력 시스템

## 전체 구성

두 개의 독립된 산출물로 구성됩니다.

```
qr-barcode-project/
├── web/                # ① 단독 실행되는 Web(React) 앱
│                        #    QR/바코드 생성, Browser Print로 라벨 출력,
│                        #    USB/C-Type/블루투스 스캐너 입력(키보드 웨지) 지원
│
├── webview-app/         # ② Android WebView 안에서 로드되는 React 앱
│                        #    QR/바코드 생성, Android 브리지를 통한 라벨 출력
│
└── android/              # ②를 감싸는 Android 네이티브 앱 (WebView 셸)
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── build.gradle
        ├── assets/www/    # webview-app 빌드 결과물이 들어갈 자리
        ├── java/com/company/qrbarcode/
        │   ├── MainActivity.java       # WebView 설정 및 로드
        │   ├── WebAppInterface.java    # JS ↔ Java 브리지
        │   └── printer/ZebraPrinterHelper.java
        └── res/layout/activity_main.xml
```

## ① Web(React) 단독 실행

```bash
cd web
npm install
npm start
```

- `ScanPanel` 컴포넌트가 화면에 항상 떠 있으며, USB/C-Type/블루투스로 연결된 Zebra 스캐너로
  스캔하면(키보드 웨지 모드 기준) 자동으로 감지되어 아래 `LabelPrinter`의 입력값을 채웁니다.
- 라벨 출력은 Zebra Browser Print 에이전트 설치 후 가능합니다. (이전 안내 참고)

**스캐너가 키보드 웨지 모드인지 확인하는 법**: 메모장이나 아무 텍스트 입력창을 열어두고 스캔했을 때
그 값이 그대로 타이핑되어 들어오면 키보드 웨지 모드입니다. Zebra 스캐너는 대부분 기본값이 이 모드입니다.

## ② Android WebView 앱

### 2-1. webview-app을 먼저 빌드

```bash
cd webview-app
npm install
npm run build
```

### 2-2. 빌드 결과물을 Android assets로 복사

`webview-app/build/` 폴더의 내용 전체를 `android/app/src/main/assets/www/`로 복사합니다.

### 2-3. Android 프로젝트 설정

1. Zebra Link-OS SDK jar를 `android/app/libs/`에 넣기
2. `app/build.gradle`에 의존성 추가 확인 (androidx.webkit, Link-OS jar)
3. Android Studio에서 `android/` 폴더 열고 Gradle Sync

### 2-4. 동작 방식

- `MainActivity`가 `WebViewAssetLoader`로 assets/www를 가상 도메인처럼 서빙해서 WebView에 로드합니다.
- WebView 안의 React 코드에서 라벨 출력 버튼을 누르면 `window.Android.printLabel(zpl)`이 호출되고,
  이는 Java의 `WebAppInterface.printLabel()`로 이어져 실제 Bluetooth 프린터로 출력됩니다.
- 출력 결과는 다시 `window.onPrintResult(success, message)` 형태로 JS에 전달할 수 있게 되어 있습니다
  (필요하면 웹 쪽에서 이 함수를 정의해서 결과를 화면에 표시하세요).

## 공통 준비물

- `web`, `webview-app` 둘 다 폐쇄망이면 `qrcode.react`, `jsbarcode`를 `npm pack`으로 미리 받아 반입
- `MainActivity`, `WebAppInterface`의 `DEMO_PRINTER_MAC` 값을 실제 프린터 MAC 주소로 변경 필요
