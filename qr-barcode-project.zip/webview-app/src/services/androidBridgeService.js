// androidBridgeService.js
//
// Android WebView 안에서 실행될 때, Java 쪽에서
// webView.addJavascriptInterface(new WebAppInterface(this), "Android")
// 로 등록해둔 네이티브 브리지 객체(window.Android)를 통해 라벨을 출력합니다.
//
// 대응하는 Java 코드: android/app/src/main/java/com/company/qrbarcode/WebAppInterface.java

/**
 * window.Android 브리지가 정상적으로 주입되어 있는지 확인합니다.
 * (일반 브라우저에서 이 페이지를 열면 브리지가 없으므로 여기서 걸러짐)
 */
function ensureBridgeAvailable() {
  if (typeof window === "undefined" || !window.Android) {
    throw new Error(
      "Android 브리지를 찾을 수 없습니다. 이 화면은 Android 앱의 WebView 안에서만 정상 동작합니다."
    );
  }
}

/**
 * ZPL 문자열을 Android 네이티브 코드로 전달해 라벨을 출력합니다.
 * Java 쪽 WebAppInterface.printLabel(String zpl)이 실제 Link-OS SDK 호출을 담당합니다.
 *
 * @param {string} zpl - 출력할 ZPL 명령 문자열
 */
export function printZplViaAndroid(zpl) {
  ensureBridgeAvailable();
  // Java 메서드는 동기 호출이지만, 실제 출력은 Java 쪽에서 별도 스레드로 처리하도록
  // WebAppInterface를 구현해뒀습니다. (WebView 메인 스레드를 막지 않기 위함)
  window.Android.printLabel(zpl);
}

/**
 * QR코드용 ZPL 라벨 문자열 생성 (web 프로젝트와 동일한 포맷)
 */
export function buildQrLabelZpl(value, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BQN,2,6
^FDQA,${value}^FS
^XZ
  `.trim();
}

/**
 * CODE128 바코드용 ZPL 라벨 문자열 생성
 */
export function buildBarcodeLabelZpl(value, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BY2
^BCN,80,Y,N,N
^FD${value}^FS
^XZ
  `.trim();
}
