// QrCodeGenerator.jsx
// web 프로젝트와 동일한 컴포넌트입니다. (Android WebView 안에서 실행됨)

import React from "react";
import QRCode from "qrcode.react";

function QrCodeGenerator({ value, size = 180 }) {
  if (!value) {
    return <div style={{ color: "#999" }}>QR코드로 변환할 값을 입력하세요.</div>;
  }

  return (
    <div className="qr-code-wrapper">
      <QRCode value={value} size={size} level="M" renderAs="canvas" />
    </div>
  );
}

export default QrCodeGenerator;
