// BarcodeGenerator.jsx
// web 프로젝트와 동일한 컴포넌트입니다. (Android WebView 안에서 실행됨)

import React from "react";
import JsBarcode from "jsbarcode";

function BarcodeGenerator({ value, format = "CODE128", height = 60 }) {
  const svgRef = React.useRef(null);

  React.useEffect(() => {
    if (!value || !svgRef.current) return;

    try {
      JsBarcode(svgRef.current, value, {
        format: format,
        height: height,
        displayValue: true,
        margin: 8,
      });
    } catch (err) {
      console.error("바코드 생성 실패:", err.message);
    }
  }, [value, format, height]);

  if (!value) {
    return <div style={{ color: "#999" }}>바코드로 변환할 값을 입력하세요.</div>;
  }

  return <svg ref={svgRef} className="barcode-svg" />;
}

export default BarcodeGenerator;
