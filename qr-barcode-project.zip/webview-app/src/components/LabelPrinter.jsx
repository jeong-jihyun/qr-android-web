// LabelPrinter.jsx
// QR코드/바코드 미리보기 + Android 브리지를 통한 라벨 출력을 담당하는 컴포넌트
// (webview-app 전용: Browser Print가 아니라 Android 네이티브 브리지로 출력)

import React from "react";
import QrCodeGenerator from "./QrCodeGenerator";
import BarcodeGenerator from "./BarcodeGenerator";
import {
  printZplViaAndroid,
  buildQrLabelZpl,
  buildBarcodeLabelZpl,
} from "../services/androidBridgeService";

function LabelPrinter() {
  const [inputValue, setInputValue] = React.useState("");
  const [labelType, setLabelType] = React.useState("qr");
  const [statusMessage, setStatusMessage] = React.useState("");

  const handlePrint = () => {
    if (!inputValue) {
      setStatusMessage("먼저 값을 입력하세요.");
      return;
    }

    const zpl =
      labelType === "qr"
        ? buildQrLabelZpl(inputValue, "QR Label")
        : buildBarcodeLabelZpl(inputValue, "Barcode Label");

    try {
      printZplViaAndroid(zpl);
      setStatusMessage("Android로 출력 요청을 보냈습니다.");
      // 실제 출력 성공/실패 결과는 Java 쪽 Toast로 표시됩니다.
      // 필요하다면 WebAppInterface에서 evaluateJavascript로 콜백을 보내
      // 이 화면에도 성공/실패를 반영할 수 있습니다 (README 참고).
    } catch (err) {
      setStatusMessage("오류: " + err.message);
    }
  };

  return (
    <div style={{ maxWidth: 360 }}>
      <h3>라벨 생성 및 출력</h3>

      <input
        type="text"
        placeholder="Work Order 번호 등 입력"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        style={{ width: "100%", marginBottom: 8 }}
      />

      <div style={{ marginBottom: 8 }}>
        <label>
          <input
            type="radio"
            checked={labelType === "qr"}
            onChange={() => setLabelType("qr")}
          />
          QR코드
        </label>
        <label style={{ marginLeft: 12 }}>
          <input
            type="radio"
            checked={labelType === "barcode"}
            onChange={() => setLabelType("barcode")}
          />
          바코드
        </label>
      </div>

      <div style={{ marginBottom: 12 }}>
        {labelType === "qr" ? (
          <QrCodeGenerator value={inputValue} />
        ) : (
          <BarcodeGenerator value={inputValue} />
        )}
      </div>

      <button onClick={handlePrint}>라벨 출력</button>

      {statusMessage && <p style={{ marginTop: 8 }}>{statusMessage}</p>}
    </div>
  );
}

export default LabelPrinter;
