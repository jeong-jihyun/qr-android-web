// App.jsx
import React from "react";
import LabelPrinter from "./components/LabelPrinter";

function App() {
  return (
    <div style={{ padding: 24 }}>
      <h1>QR/바코드 라벨 시스템 (Android WebView)</h1>
      <LabelPrinter />
    </div>
  );
}

export default App;
