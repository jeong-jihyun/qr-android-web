package com.company.qrbarcode;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.company.qrbarcode.printer.ZebraPrinterHelper;

/**
 * WebAppInterface
 *
 * WebView 안의 자바스크립트에서 window.Android.printLabel(zpl) 형태로 호출하면
 * 이 클래스의 printLabel() 메서드가 실행됩니다.
 * (JS 쪽 대응 코드: webview-app/src/services/androidBridgeService.js)
 *
 * 등록 방법 (MainActivity 참고):
 *   webView.addJavascriptInterface(new WebAppInterface(this, webView), "Android");
 *
 * 주의: @JavascriptInterface 애노테이션이 붙은 public 메서드만 JS에서 호출 가능합니다.
 */
public class WebAppInterface {

    // 데모용 프린터 MAC 주소. 실제로는 설정 화면에서 입력받아 SharedPreferences 등에 저장하는 것을 권장합니다.
    private static final String DEMO_PRINTER_MAC = "AA:BB:CC:DD:EE:FF";

    private final Activity activity;
    private final WebView webView;
    private final ZebraPrinterHelper printerHelper = new ZebraPrinterHelper();

    public WebAppInterface(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    /**
     * JS에서 호출하는 라벨 출력 메서드.
     * 프린터 통신은 블로킹 I/O이므로 반드시 별도 스레드에서 실행합니다.
     * (WebView JS 호출은 기본적으로 별도 스레드에서 실행되긴 하지만,
     *  안전하게 명시적으로 새 스레드를 띄웁니다)
     */
    @JavascriptInterface
    public void printLabel(String zpl) {
        new Thread(() -> {
            try {
                printerHelper.printZpl(DEMO_PRINTER_MAC, zpl);
                notifyResultToWeb(true, "출력 완료");
            } catch (Exception e) {
                notifyResultToWeb(false, "출력 실패: " + e.getMessage());
            }
        }).start();
    }

    /**
     * 출력 결과를 다시 웹(JS) 쪽으로 알려주고 싶을 때 사용합니다.
     * JS 쪽에서 window.onPrintResult 함수를 정의해두면 결과를 받을 수 있습니다.
     *   예) window.onPrintResult = function(success, message) { ... }
     */
    private void notifyResultToWeb(boolean success, String message) {
        activity.runOnUiThread(() -> {
            // evaluateJavascript는 반드시 메인(UI) 스레드에서 호출해야 함
            String script = String.format(
                    "window.onPrintResult && window.onPrintResult(%b, '%s');",
                    success, message.replace("'", "\\'"));
            webView.evaluateJavascript(script, null);
        });
    }
}
