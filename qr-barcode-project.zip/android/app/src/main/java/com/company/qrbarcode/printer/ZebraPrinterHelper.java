package com.company.qrbarcode.printer;

import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.Connection;
import com.zebra.sdk.comm.ConnectionException;

/**
 * ZebraPrinterHelper
 *
 * Zebra Link-OS SDK(Android)를 사용해 Bluetooth로 연결된 프린터에
 * ZPL 명령을 전송하는 기능을 감싸놓은 헬퍼 클래스입니다.
 *
 * 사전 준비:
 * - Link-OS Multiplatform SDK에서 받은 jar(예: ZSDK_ANDROID_API.jar)를
 *   app/libs 폴더에 넣고 build.gradle의 dependencies에 추가해야 합니다.
 */
public class ZebraPrinterHelper {

    /**
     * 지정한 MAC 주소의 Zebra 프린터에 ZPL 문자열을 전송합니다.
     *
     * @param printerMacAddress 프린터의 Bluetooth MAC 주소
     * @param zpl               전송할 ZPL 명령 문자열
     * @throws ConnectionException 연결 또는 통신 실패 시 발생
     */
    public void printZpl(String printerMacAddress, String zpl) throws ConnectionException {
        Connection connection = new BluetoothConnection(printerMacAddress);

        try {
            connection.open();
            connection.write(zpl.getBytes());
        } finally {
            if (connection.isConnected()) {
                connection.close();
            }
        }
    }
}
