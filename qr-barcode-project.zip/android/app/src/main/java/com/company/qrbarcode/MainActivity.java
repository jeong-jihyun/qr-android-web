package com.company.qrbarcode;

import android.os.Bundle;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

/**
 * MainActivity
 *
 * webview-app(React)을 빌드한 결과물을 app/src/main/assets/www 폴더에 넣고,
 * WebViewAssetLoader로 로컬 https 도메인처럼 서빙해서 WebView에 띄웁니다.
 *
 * file:// 로 직접 로드하지 않는 이유:
 * - file:// 스킴은 최신 WebView 보안 정책상 일부 JS 기능(fetch 등)이 제한될 수 있습니다.
 * - WebViewAssetLoader를 쓰면 https://appassets.androidplatform.net 같은
 *   가상 도메인으로 서빙되어 일반 웹앱과 동일하게 동작합니다. (실제 인터넷 접속은 아님)
 *
 * 사전 준비:
 * 1) webview-app 폴더에서 `npm install` 후 `npm run build`
 * 2) 생성된 build/ 폴더 내용을 android/app/src/main/assets/www 로 복사
 * 3) build.gradle에 androidx.webkit 의존성 추가
 *    implementation 'androidx.webkit:webkit:1.4.0'
 */
public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        setupWebView();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // React 앱 실행을 위해 필수
        settings.setDomStorageEnabled(true); // localStorage 등 사용 시 필요

        // assets/www 폴더를 가상 도메인으로 서빙해주는 로더
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        // JS ↔ Java 브리지 등록: JS에서 window.Android.printLabel(zpl) 형태로 호출 가능해짐
        webView.addJavascriptInterface(new WebAppInterface(this, webView), "Android");

        // assets/www/index.html 로드 (React 빌드 결과물의 진입점)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    @Override
    protected void onDestroy() {
        // 메모리 누수 방지를 위해 WebView 정리
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
