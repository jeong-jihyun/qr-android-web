# 사양 명세서 및 사용자 작업 체크리스트

이 문서는 (1) 정확히 맞춰야 하는 버전 사양과 (2) 코드/설정 중 **사용자가 직접 해야 하는 부분**을
구분해서 정리한 것입니다. 프로젝트 파일 자체는 이미 이 사양대로 구성되어 있습니다.

---

## 1. 정확한 버전 사양

### 1-1. PC(React) 측

| 항목 | 버전 | 비고 |
| --- | --- | --- |
| Node.js | 12.22.x LTS | 12.x 계열이면 동작하나 12.22 권장 |
| npm | Node 12.22 동봉 버전(6.14.x) | 별도 설치 불필요 |
| React / ReactDOM | 16.13.1 | `frontend/package.json`에 고정됨 |
| react-scripts (CRA) | 3.4.1 | Node 12와 호환되는 마지막 계열 |
| qrcode.react | ^1.0.1 | QR 생성 |
| jsbarcode | ^3.11.5 | 1D 바코드 생성 |
| Zebra Browser Print (JS SDK) | 3.0.216 이상 | Zebra 사이트에서 별도 다운로드 필요 (npm 미배포) |
| Zebra Browser Print 에이전트 | 최신 안정 버전 | PC에 상주 프로그램으로 설치 (OS별 설치파일 별도) |
| html5-qrcode | ^2.3.8 | 카메라로 QR/바코드 스캔 (npm 배포, 별도 다운로드 불필요) |

### 1-2. 모바일(Android) 측

| 항목 | 버전 | 비고 |
| --- | --- | --- |
| Android Studio | 4.1.3 이상 | |
| Android Gradle Plugin (AGP) | **4.1.3** | `android/build.gradle`에 고정됨 |
| Gradle 배포판 | **6.7.1** | `android/gradle/wrapper/gradle-wrapper.properties`에 고정됨 |
| JDK | **1.8 (Java 8)** | `compileOptions`에 1.8로 고정됨. 커맨드라인 빌드 시 실제 JAVA_HOME도 8이어야 함 |
| compileSdkVersion | 30 | |
| minSdkVersion | 21 | |
| targetSdkVersion | 30 | |
| Zebra Link-OS SDK (Android) | 최신 안정 버전 | Zebra 사이트에서 별도 다운로드 필요 (Maven 미배포), jar를 직접 추가해야 함 |
| DataWedge | 단말 출고 시 기본 탑재 버전 | Zebra 단말 자체 앱, 별도 설치 불필요 |
| zxing-android-embedded | 4.3.0 | 카메라로 QR/바코드 스캔 (mavenCentral 배포, `build.gradle`에 이미 활성화됨) |

---

## 2. 사용자가 직접 해야 하는 부분 (체크리스트)

아래 항목들은 라이선스/하드웨어/개인 환경 문제로 **자동으로 대신 처리할 수 없어** 직접 진행해야 합니다.

### PC(React) 측

- [ ] **Node.js 12.22 LTS 설치 확인** (`node -v`)
- [ ] **Zebra Browser Print 에이전트 설치**
  (https://www.zebra.com/us/en/support-downloads/software/printer-software/browser-print.html)
  실물 프린터 없이 테스트만 할 경우 이 단계는 생략 가능 (자동으로 Mock 모드로 동작)
- [ ] **Browser Print JS SDK 파일 배치**
  위 페이지에서 `BrowserPrint-3.x.x.min.js` 다운로드 →
  `frontend/public/BrowserPrint-3.0.216.min.js` 경로에 저장
  (버전이 다르면 `frontend/public/index.html`의 `<script src="...">` 파일명도 함께 수정)
- [ ] `npm install` 실행 (frontend 폴더 안에서)
- [ ] 실물 프린터로 테스트 시 프린터를 USB로 연결하고 Browser Print 에이전트에서 인식되는지 확인

### 모바일(Android) 측

- [ ] **JDK 8 설치 확인**, 커맨드라인에서 `java -version`이 8인지 확인
  8이 아니면 `android/gradle.properties`의 `org.gradle.java.home` 주석 해제 후 JDK 8 경로 입력
- [ ] **Zebra Link-OS SDK(Android) 다운로드**
  (https://www.zebra.com/us/en/support-downloads/software/link-os-drivers/link-os-multi-platform-sdk.html)
  받은 파일 중 jar를 `android/app/libs/ZSDK_ANDROID_API.jar` 경로에 저장
- [ ] `android/app/build.gradle`에서 아래 줄의 주석(`//`) 해제
  ```
  implementation files('libs/ZSDK_ANDROID_API.jar')
  ```
- [ ] **앱 패키지명 확인/변경**: 현재 `com.beyondf.zebraqr`로 되어 있음.
  실제 배포할 패키지명이 다르면 아래 3곳을 함께 수정해야 함
  - `android/app/build.gradle` → `applicationId`
  - `android/app/src/main/AndroidManifest.xml` → `package`
  - `android/app/src/main/java/com/beyondf/zebraqr/` 폴더 경로 및 각 파일의 `package` 선언
- [ ] **DataWedge 프로필 설정** (Zebra 단말에서 직접, 코드로 자동화 불가능)
  1. 단말의 DataWedge 앱 실행 → 새 프로필 생성
  2. Associated Apps: 위에서 확정한 실제 패키지명 등록
  3. Barcode Input 활성화, 필요한 심볼로지(QR Code, Code128 등) 체크
  4. Intent Output 활성화 → Intent Action: `com.beyondf.zebraqr.SCAN` (패키지명 바꾼 경우 그에 맞게),
     Intent Delivery: Broadcast Intent
- [ ] **실제 프린터 연결 정보 입력**
  `MainActivity.java`의 `printLastScannedAsLabel(String printerIp)` 호출부에
  실제 프린터 IP(네트워크) 또는 `ZebraPrinterHelper.connectBluetooth(macAddress)`에 실제 MAC 주소 입력
  (하드웨어 없이 테스트만 할 경우 이 두 값은 비워두고 Mock/미리보기 흐름만 사용해도 됨)

---

## 3. 이미 처리되어 있어 추가로 손댈 필요 없는 부분

- React 컴포넌트(QR/바코드 생성, 스캐너 입력 캡처, ZPL 라벨 템플릿)
- Android 매니페스트의 권한 선언, DataWedge 브로드캐스트 리시버 등록
- Gradle 버전 조합(AGP 4.1.3 / Gradle 6.7.1) 고정
- 실물 장비 없이 테스트할 수 있는 Mock 프린터 / Labelary ZPL 미리보기 / 스캔 시뮬레이션 로직
- 카메라 기반 QR/바코드 스캔 (PC: `CameraScanner.js` + html5-qrcode / Android: `MainActivity.startCameraScan()` + zxing-android-embedded)
  — 전용 스캐너·DataWedge가 없는 환경의 보조 스캔 수단
