import React, { useState } from "react";
import QRGenerator from "./components/QRGenerator";
import BarcodeGenerator from "./components/BarcodeGenerator";
import ScannerInput from "./components/ScannerInput";
import CameraScanner from "./components/CameraScanner";
import "./App.css";

export default function App() {
  const [scannedHistory, setScannedHistory] = useState([]);

  const handleScan = (code) => {
    setScannedHistory((prev) => [code, ...prev].slice(0, 20));
  };

  return (
    <div className="app">
      <header>
        <h1>Zebra QR/바코드 스캐너·프린터 연동</h1>
        <p>PC(React) 데모 - QR/바코드 생성, 스캔 입력(물리 스캐너/카메라), 라벨 출력</p>
      </header>
      <main className="grid">
        <QRGenerator />
        <BarcodeGenerator />
        <ScannerInput onScan={handleScan} />
        <CameraScanner onScan={handleScan} />
      </main>

      {scannedHistory.length > 0 && (
        <section className="panel">
          <h2>전체 스캔 이력 (물리 스캐너 + 카메라 통합)</h2>
          <ul className="scan-log">
            {scannedHistory.map((code, idx) => (
              <li key={idx}>{code}</li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
