import React, { useState, useRef } from "react";
import QRCode from "qrcode.react";
import { printQrLabel } from "../services/zebraBrowserPrint";

/**
 * QR코드 생성 및 미리보기, Zebra 프린터로 라벨 출력을 담당하는 컴포넌트
 */
export default function QRGenerator() {
  const [value, setValue] = useState("");
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState("");
  const qrWrapRef = useRef(null);

  const handlePrint = async () => {
    if (!value) {
      setStatus("QR코드에 넣을 값을 입력하세요.");
      return;
    }
    try {
      setStatus("프린터로 전송 중...");
      await printQrLabel(value, title);
      setStatus("출력 요청 완료");
    } catch (err) {
      setStatus(`출력 실패: ${err.message}`);
    }
  };

  return (
    <section className="panel">
      <h2>QR코드 생성</h2>
      <label>
        라벨 제목
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="예: 자재코드"
        />
      </label>
      <label>
        QR 값
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="QR코드로 변환할 텍스트/코드"
        />
      </label>

      <div ref={qrWrapRef} className="qr-preview">
        {value ? <QRCode value={value} size={160} level="M" includeMargin /> : <span className="placeholder">미리보기</span>}
      </div>

      <button type="button" onClick={handlePrint} disabled={!value}>
        라벨 프린터로 출력
      </button>
      {status && <p className="status">{status}</p>}
    </section>
  );
}
