import React, { useEffect, useRef, useState, useCallback } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";

/**
 * 카메라(웹캠/모바일 브라우저 카메라)로 QR코드·바코드를 스캔하는 컴포넌트.
 *
 * Zebra 전용 스캐너나 DataWedge가 없는 PC/노트북/일반 스마트폰에서도
 * 바로 테스트할 수 있도록 하기 위한 보조 스캔 경로입니다.
 * (물리 스캐너 입력은 ScannerInput.js, 이 컴포넌트는 카메라 입력 담당)
 *
 * 주의:
 * - 브라우저 카메라 권한이 필요하며, HTTPS 또는 localhost 환경에서만 카메라 접근이 허용됩니다.
 * - 라이브러리 내부적으로 ZXing을 사용해 QR코드와 다양한 1D 바코드(Code128, EAN, UPC 등)를 모두 인식합니다.
 */

const ELEMENT_ID = "camera-scanner-viewport";

const SUPPORTED_FORMATS = [
  Html5QrcodeSupportedFormats.QR_CODE,
  Html5QrcodeSupportedFormats.CODE_128,
  Html5QrcodeSupportedFormats.EAN_13,
  Html5QrcodeSupportedFormats.EAN_8,
  Html5QrcodeSupportedFormats.UPC_A,
  Html5QrcodeSupportedFormats.UPC_E,
  Html5QrcodeSupportedFormats.CODE_39,
];

export default function CameraScanner({ onScan }) {
  const [isRunning, setIsRunning] = useState(false);
  const [lastResult, setLastResult] = useState("");
  const [error, setError] = useState("");
  const scannerRef = useRef(null);

  const stopScanner = useCallback(async () => {
    const scanner = scannerRef.current;
    if (scanner && isRunning) {
      try {
        await scanner.stop();
        scanner.clear();
      } catch (e) {
        // 이미 정지된 경우 등은 무시
      }
    }
    setIsRunning(false);
  }, [isRunning]);

  useEffect(() => {
    // 언마운트 시 카메라를 반드시 해제 (켜둔 채로 페이지를 벗어나는 것 방지)
    return () => {
      stopScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startScanner = async () => {
    setError("");
    try {
      const scanner = new Html5Qrcode(ELEMENT_ID, {
        formatsToSupport: SUPPORTED_FORMATS,
        verbose: false,
      });
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: "environment" }, // 모바일이면 후면 카메라 우선
        { fps: 10, qrbox: { width: 240, height: 240 } },
        (decodedText) => {
          setLastResult(decodedText);
          if (onScan) onScan(decodedText);
        },
        () => {
          // 프레임마다 인식 실패는 정상 흐름이므로 무시 (콘솔에 로그만 남기지 않음)
        }
      );
      setIsRunning(true);
    } catch (e) {
      setError(
        `카메라를 시작할 수 없습니다: ${e.message || e}. ` +
          "카메라 권한을 허용했는지, HTTPS/localhost 환경인지 확인하세요."
      );
      setIsRunning(false);
    }
  };

  return (
    <section className="panel">
      <h2>카메라 스캔 (QR/바코드)</h2>
      <p className="hint">
        Zebra 전용 스캐너나 DataWedge가 없는 환경에서 노트북/스마트폰 카메라로 바로 테스트할 수 있습니다.
      </p>

      <div id={ELEMENT_ID} className="camera-viewport" />

      <div className="camera-controls">
        {!isRunning ? (
          <button type="button" onClick={startScanner}>
            카메라 스캔 시작
          </button>
        ) : (
          <button type="button" onClick={stopScanner}>
            카메라 스캔 중지
          </button>
        )}
      </div>

      <div className="scan-result">
        <strong>마지막 인식 값:</strong> {lastResult || "-"}
      </div>
      {error && <p className="status error">{error}</p>}
    </section>
  );
}
