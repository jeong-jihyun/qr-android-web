import React, { useState, useRef, useEffect } from "react";
import JsBarcode from "jsbarcode";
import { printBarcodeLabel } from "../services/zebraBrowserPrint";

/**
 * 1D 바코드(Code128) 생성 및 미리보기, Zebra 프린터로 라벨 출력을 담당하는 컴포넌트
 */
export default function BarcodeGenerator() {
  const [value, setValue] = useState("");
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState("");
  const svgRef = useRef(null);

  useEffect(() => {
    if (value && svgRef.current) {
      try {
        JsBarcode(svgRef.current, value, {
          format: "CODE128",
          width: 2,
          height: 60,
          displayValue: true,
        });
      } catch (err) {
        setStatus(`바코드 생성 실패: ${err.message}`);
      }
    }
  }, [value]);

  const handlePrint = async () => {
    if (!value) {
      setStatus("바코드에 넣을 값을 입력하세요.");
      return;
    }
    try {
      setStatus("프린터로 전송 중...");
      await printBarcodeLabel(value, title);
      setStatus("출력 요청 완료");
    } catch (err) {
      setStatus(`출력 실패: ${err.message}`);
    }
  };

  return (
    <section className="panel">
      <h2>바코드 생성 (Code128)</h2>
      <label>
        라벨 제목
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="예: 제품코드"
        />
      </label>
      <label>
        바코드 값
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="바코드로 변환할 텍스트/코드"
        />
      </label>

      <div className="barcode-preview">
        <svg ref={svgRef} />
        {!value && <span className="placeholder">미리보기</span>}
      </div>

      <button type="button" onClick={handlePrint} disabled={!value}>
        라벨 프린터로 출력
      </button>
      {status && <p className="status">{status}</p>}
    </section>
  );
}
