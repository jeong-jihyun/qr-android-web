import React, { useState, useEffect, useRef, useCallback } from "react";

/**
 * Zebra 스캐너(키보드 웨지/HID 모드)로부터 들어오는 스캔 데이터를 캡처하는 컴포넌트
 *
 * 동작 원리:
 * - Zebra 스캐너는 대부분 "키보드 웨지" 모드로 설정하면 사람이 타이핑하듯
 *   매우 빠른 속도로 문자를 입력하고 마지막에 Enter(또는 Tab)를 전송한다.
 * - 사람이 타이핑하는 속도(수백ms 이상 간격)와 스캐너 입력 속도(수십ms 이하 간격)를
 *   구분하여, 짧은 간격으로 들어온 입력 뭉치 + Enter 를 "스캔 이벤트"로 판단한다.
 * - 스캐너를 별도 설정으로 특정 프리픽스/서픽스를 붙이도록 구성했다면 그 값도 함께 확인 가능.
 */
const SCAN_GAP_THRESHOLD_MS = 50; // 이 값보다 빠르게 연속 입력되면 스캐너로 간주
const MIN_SCAN_LENGTH = 3;

export default function ScannerInput({ onScan }) {
  const [lastScan, setLastScan] = useState("");
  const [log, setLog] = useState([]);
  const bufferRef = useRef("");
  const lastKeyTimeRef = useRef(0);

  const handleScanComplete = useCallback(
    (code) => {
      if (code.length < MIN_SCAN_LENGTH) return;
      setLastScan(code);
      setLog((prev) => [{ code, time: new Date().toLocaleTimeString() }, ...prev].slice(0, 10));
      if (onScan) onScan(code);
    },
    [onScan]
  );

  useEffect(() => {
    const handleKeyDown = (e) => {
      const now = Date.now();
      const gap = now - lastKeyTimeRef.current;
      lastKeyTimeRef.current = now;

      // 사람이 입력하는 속도라면(간격이 크면) 버퍼를 리셋 - 일반 폼 입력을 방해하지 않기 위함
      if (gap > SCAN_GAP_THRESHOLD_MS * 6 && bufferRef.current.length > 0) {
        bufferRef.current = "";
      }

      if (e.key === "Enter" || e.key === "Tab") {
        if (bufferRef.current.length >= MIN_SCAN_LENGTH && gap < SCAN_GAP_THRESHOLD_MS * 6) {
          handleScanComplete(bufferRef.current);
        }
        bufferRef.current = "";
        return;
      }

      if (e.key.length === 1) {
        bufferRef.current += e.key;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleScanComplete]);

  return (
    <section className="panel">
      <h2>스캐너 입력 (Zebra 바코드/QR 스캐너)</h2>
      <p className="hint">
        Zebra 스캐너를 키보드 웨지 모드로 연결한 상태에서 아무 곳이나 스캔하면 자동으로 인식됩니다.
      </p>
      <div className="scan-result">
        <strong>마지막 스캔 값:</strong> {lastScan || "-"}
      </div>
      <ul className="scan-log">
        {log.map((item, idx) => (
          <li key={idx}>
            [{item.time}] {item.code}
          </li>
        ))}
      </ul>
    </section>
  );
}
