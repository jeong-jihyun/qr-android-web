/**
 * Zebra Browser Print SDK 래퍼
 * - PC에 설치된 Zebra Browser Print 에이전트와 통신하여
 *   USB/네트워크로 연결된 Zebra 라벨 프린터에 ZPL을 전송한다.
 * - window.BrowserPrint 는 public/index.html 에서 로드한 BrowserPrint SDK가 주입한다.
 *
 * 장비가 없는 개발/테스트 환경 지원:
 * - BrowserPrint SDK나 에이전트, 실물 프린터가 없어도 앱이 죽지 않도록
 *   자동으로 "Mock 프린터"로 폴백한다 (isMockMode()로 현재 모드 확인 가능).
 * - 실제 출력물 확인은 Labelary(온라인 ZPL 렌더러)로 ZPL을 이미지로 미리보기 한다
 *   (fetchZplPreview 참고, 인터넷 연결 필요).
 */

let mockMode = false;

const getSDK = () => {
  if (typeof window === "undefined" || !window.BrowserPrint) {
    mockMode = true;
    return null;
  }
  mockMode = false;
  return window.BrowserPrint;
};

/** 현재 Mock(가상 프린터) 모드로 동작 중인지 여부 */
export function isMockMode() {
  return mockMode;
}

const buildMockDevice = (name = "Mock Printer (장비 없음 - 테스트용)") => ({
  name,
  uid: "mock-printer",
  isMock: true,
  send: (zpl, success) => {
    // eslint-disable-next-line no-console
    console.info(`[Mock 프린터] "${name}" 로 ZPL 전송됨:\n${zpl}`);
    setTimeout(() => success && success(), 150); // 실제 전송처럼 약간의 지연을 흉내낸다
  },
});

/**
 * 연결 가능한 기본(디폴트) 프린터를 가져온다.
 * SDK/에이전트가 없으면 Mock 프린터를 반환한다 (예외를 던지지 않음).
 * @returns {Promise<object>} BrowserPrint device 객체 (또는 Mock 객체)
 */
export function getDefaultPrinter() {
  const BrowserPrint = getSDK();
  if (!BrowserPrint) {
    return Promise.resolve(buildMockDevice());
  }
  return new Promise((resolve) => {
    BrowserPrint.getDefaultDevice(
      "printer",
      (device) => resolve(device),
      () => resolve(buildMockDevice("Mock Printer (기본 프린터 조회 실패)"))
    );
  });
}

/**
 * 로컬(USB/네트워크)에 연결된 모든 프린터 목록을 가져온다.
 * SDK/에이전트가 없으면 Mock 프린터 1대짜리 목록을 반환한다.
 * @returns {Promise<object[]>}
 */
export function getLocalPrinters() {
  const BrowserPrint = getSDK();
  if (!BrowserPrint) {
    return Promise.resolve([buildMockDevice()]);
  }
  return new Promise((resolve) => {
    BrowserPrint.getLocalDevices(
      (deviceList) => resolve(deviceList.printer || []),
      () => resolve([buildMockDevice("Mock Printer (장치 목록 조회 실패)")]),
      "printer"
    );
  });
}

/**
 * 지정한 프린터로 ZPL 원시 명령을 전송한다. (Mock 장치도 동일한 인터페이스로 동작)
 * @param {object} device BrowserPrint device 객체 (또는 Mock 객체)
 * @param {string} zpl ZPL 문자열
 */
export function sendZPL(device, zpl) {
  return new Promise((resolve, reject) => {
    device.send(
      zpl,
      () => resolve(true),
      (error) => reject(new Error(error))
    );
  });
}

/**
 * Labelary 온라인 렌더러로 ZPL을 실제 라벨 이미지(PNG)로 렌더링한다.
 * 실물 프린터 없이 "이 ZPL이 실제로 어떻게 인쇄되는지" 눈으로 확인할 때 사용한다.
 * 인터넷 연결이 필요하며, 사내망 방화벽에서 api.labelary.com 이 차단되어 있으면 실패할 수 있다.
 *
 * @param {string} zpl ZPL 문자열
 * @param {object} opts { widthIn, heightIn, dpmm } 라벨 크기(인치)와 해상도(dot per mm, 8|12|24)
 * @returns {Promise<string>} 이미지로 사용할 수 있는 Blob Object URL
 */
export async function fetchZplPreview(zpl, opts = {}) {
  const { widthIn = 4, heightIn = 2, dpmm = 8 } = opts;
  const url = `https://api.labelary.com/v1/printers/${dpmm}dpmm/labels/${widthIn}x${heightIn}/0/`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "image/png" },
    body: zpl,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Labelary 미리보기 실패 (${res.status}): ${text || "네트워크/방화벽 확인 필요"}`);
  }
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

/**
 * QR코드가 포함된 라벨 ZPL을 생성한다.
 * @param {string} data QR코드에 인코딩할 값
 * @param {string} title 라벨 상단에 출력할 텍스트
 */
export function buildQrLabelZpl(data, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BQN,2,6
^FDQA,${data}^FS
^XZ
`.trim();
}

/**
 * 1D 바코드(Code128)가 포함된 라벨 ZPL을 생성한다.
 * @param {string} data 바코드에 인코딩할 값
 * @param {string} title 라벨 상단에 출력할 텍스트
 */
export function buildBarcodeLabelZpl(data, title = "") {
  return `
^XA
^CI28
^FO50,30^A0N,30,30^FD${title}^FS
^FO50,80^BCN,100,Y,N,N
^FD${data}^FS
^XZ
`.trim();
}

/**
 * QR 라벨을 지정 프린터(또는 기본 프린터)로 바로 출력한다.
 */
export async function printQrLabel(data, title, device) {
  const target = device || (await getDefaultPrinter());
  const zpl = buildQrLabelZpl(data, title);
  return sendZPL(target, zpl);
}

/**
 * 바코드 라벨을 지정 프린터(또는 기본 프린터)로 바로 출력한다.
 */
export async function printBarcodeLabel(data, title, device) {
  const target = device || (await getDefaultPrinter());
  const zpl = buildBarcodeLabelZpl(data, title);
  return sendZPL(target, zpl);
}
