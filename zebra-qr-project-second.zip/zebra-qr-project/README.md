# Zebra 바코드/QR 스캐너·프린터 연동 프로젝트

Zebra 사이트의 바코드 스캐너·프린터를 PC(React)와 모바일(안드로이드)에서
공통으로 사용할 수 있도록 구성한 스캐폴딩입니다.

## 구조

```
zebra-qr-project/
├── frontend/                 # PC용 React 앱
│   ├── public/
│   │   └── index.html        # Zebra Browser Print SDK 스크립트 로드 지점
│   └── src/
│       ├── components/
│       │   ├── QRGenerator.js      # QR코드 생성 + 출력
│       │   ├── BarcodeGenerator.js # 바코드(Code128) 생성 + 출력
│       │   ├── ScannerInput.js     # 키보드 웨지 스캐너 입력 캡처
│       │   └── CameraScanner.js    # 카메라로 QR/바코드 스캔 (html5-qrcode)
│       └── services/
│           └── zebraBrowserPrint.js # Browser Print SDK 래퍼 (ZPL 전송)
└── android/                  # 모바일용 안드로이드 네이티브 모듈
    └── app/
        ├── build.gradle
        └── src/main/
            ├── AndroidManifest.xml
            └── java/com/beyondf/zebraqr/
                ├── MainActivity.java
                ├── ScanReceiver.java       # DataWedge 스캔 브로드캐스트 수신
                └── ZebraPrinterHelper.java # Link-OS SDK로 라벨 출력
```

## 요구사항 대응 매핑

| 요구사항 | PC(React) | 모바일(Android) |
| --- | --- | --- |
| QR/바코드 생성 | `qrcode.react`, `jsbarcode` 라이브러리로 생성 | 필요 시 동일 로직을 웹뷰로 재사용하거나 ZXing으로 대체 가능 |
| 스캔 입력 (전용 스캐너) | 키보드 웨지 모드 스캐너 → `ScannerInput.js`에서 keydown 이벤트로 캡처 | DataWedge 프로필의 Intent Output → `ScanReceiver.java`가 브로드캐스트 수신 |
| 스캔 입력 (카메라, 보조 수단) | `html5-qrcode` → `CameraScanner.js`에서 웹캠/모바일 브라우저 카메라로 인식 | `zxing-android-embedded` → `MainActivity.startCameraScan()`이 카메라 스캔 화면 실행, `onActivityResult`로 결과 수신 |
| 라벨 출력 | Zebra Browser Print SDK(JS) → ZPL 전송 | Zebra Link-OS SDK(Java) → Bluetooth/네트워크로 ZPL 전송 |

## PC(React) 실행 방법

1. Node.js 12.22 LTS 설치 확인 (`node -v`)
2. Zebra Browser Print 에이전트를 PC에 설치·실행
   (https://www.zebra.com/us/en/support-downloads/software/printer-software/browser-print.html)
3. 같은 페이지에서 `BrowserPrint-3.0.216.min.js`(또는 최신 버전)를 받아
   `frontend/public/BrowserPrint-3.0.216.min.js` 로 배치
   (버전이 다르면 `public/index.html`의 `<script src>` 경로도 맞춰 수정)
4. 의존성 설치 및 실행

```bash
cd frontend
npm install
npm start
```

5. 스캐너는 Zebra 사이트 매뉴얼대로 "USB CDC/HID(키보드 웨지)" 모드로 설정 후
   USB로 PC에 연결 — 화면 아무 곳이나 포커스한 상태에서 스캔하면 자동 인식됩니다.

## 모바일(Android) 설정 방법

1. Android Studio 4.1.3 이상, JDK 8, compileSdk 30 / minSdk 21 확인
2. Zebra 단말(안드로이드 스캐너)에 기본 탑재된 **DataWedge** 앱에서 새 프로필 생성
   - Associated Apps: `com.beyondf.zebraqr` (본 앱 패키지명) 등록
   - Barcode Input: 활성화, 필요한 심볼로지(QR Code, Code128 등) 체크
   - Intent Output: 활성화
     - Intent Action: `com.beyondf.zebraqr.SCAN`
     - Intent Delivery: Broadcast Intent
3. Zebra Link-OS Multi-Platform SDK(Android)를 Zebra 개발자 사이트에서 다운로드하여
   `android/app/libs/ZSDK_ANDROID_API.jar` 로 배치, `app/build.gradle`의 관련 줄 주석 해제
4. `android/` 폴더를 Android Studio에서 열어 Gradle Sync 후 빌드

## `gradlew clean assembleDebug` 버전 오류 해결

Link-OS SDK jar를 넣고 빌드할 때 버전 오류가 난다면, 아래 조합을 맞춰보세요.

| 항목 | 권장 버전 |
| --- | --- |
| JDK | 1.8 (Java 8) |
| AGP (`com.android.tools.build:gradle`) | 4.1.3 |
| Gradle 배포판 | 6.7.1 |

1. `java -version` 으로 커맨드라인에서 실제 사용되는 JDK가 8인지 확인
   (Android Studio 내장 JDK가 11/17이면 `gradlew`를 터미널에서 직접 실행할 때 그 버전을 탈 수 있음)
2. JDK 8이 아니라면 `android/gradle.properties`의 `org.gradle.java.home` 줄 주석을 해제하고
   JDK 8 설치 경로를 지정
3. `android/build.gradle`의 AGP가 `4.1.3`, `android/gradle/wrapper/gradle-wrapper.properties`의
   Gradle 배포판이 `6.7.1`인지 확인 (이미 이 값으로 설정해 두었습니다)
4. 그래도 오류가 나면 정확한 오류 메시지(예: `Unsupported class file major version`,
   `Could not determine java version` 등)를 확인하면 원인을 더 좁힐 수 있습니다.

## 참고

- ZPL(Zebra Programming Language)은 대부분의 Zebra 라벨 프린터 공통 명령어이므로
  `zebraBrowserPrint.js`와 `ZebraPrinterHelper.java`의 ZPL 템플릿은 거의 동일합니다.
  라벨 크기/여백은 프린터 모델과 용지 사이즈에 맞춰 좌표(`^FO`)와 바코드 크기 옵션을 조정하세요.
- Browser Print SDK와 Link-OS SDK는 Zebra의 라이선스 배포물이라 npm/Maven에 공개돼 있지 않아
  Zebra 개발자 사이트에서 직접 받아야 합니다.
