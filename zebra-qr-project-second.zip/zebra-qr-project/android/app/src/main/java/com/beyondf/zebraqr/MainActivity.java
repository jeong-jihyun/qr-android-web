package com.beyondf.zebraqr;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/**
 * 데모 화면:
 * - DataWedge(전용 스캐너) 스캔 결과를 실시간으로 화면에 표시
 * - 카메라 스캔(ZXing) 결과도 동일한 흐름으로 처리 (전용 스캐너가 없는 단말 대응)
 * - 스캔된 값으로 라벨을 즉시 출력(버튼 클릭 시)하는 흐름의 예시
 *
 * 실제 레이아웃(activity_main.xml)은 프로젝트 UI에 맞게 구성하세요.
 * 여기서는 텍스트뷰 id: tv_scan_result 하나만 있다고 가정합니다.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private ZebraPrinterHelper printerHelper;
    private String lastScannedValue = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main); // 실제 레이아웃 연결

        printerHelper = new ZebraPrinterHelper();

        // 전용 스캐너(DataWedge) 결과 수신
        ScanReceiver.setListener((data, labelType) -> {
            lastScannedValue = data;
            runOnUiThread(() -> {
                Log.i(TAG, "화면 갱신(DataWedge): " + data);
                Toast.makeText(this, "스캔됨: " + data, Toast.LENGTH_SHORT).show();
                // TextView tv = findViewById(R.id.tv_scan_result);
                // tv.setText(data);
            });
        });

        // 예: 버튼 클릭 시 카메라 스캔 실행하도록 연결
        // findViewById(R.id.btn_camera_scan).setOnClickListener(v -> startCameraScan());
    }

    /**
     * 카메라로 QR/바코드 스캔 화면을 띄운다.
     * Zebra 전용 스캐너나 DataWedge 설정이 없는 단말(또는 개발 중 카메라로만 테스트하고 싶을 때) 사용.
     */
    private void startCameraScan() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES); // QR + 각종 1D 바코드 모두 인식
        integrator.setPrompt("QR코드 또는 바코드를 화면 중앙에 맞춰주세요");
        integrator.setBeepEnabled(true);
        integrator.setOrientationLocked(false);
        integrator.initiateScan();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Log.i(TAG, "카메라 스캔 취소됨");
            } else {
                String scanned = result.getContents();
                lastScannedValue = scanned;
                Log.i(TAG, "화면 갱신(카메라): " + scanned);
                Toast.makeText(this, "카메라 스캔됨: " + scanned, Toast.LENGTH_SHORT).show();
                // TextView tv = findViewById(R.id.tv_scan_result);
                // tv.setText(scanned);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    /** 예시: 스캔된 값으로 QR 라벨을 네트워크 프린터로 출력 */
    private void printLastScannedAsLabel(String printerIp) {
        if (lastScannedValue.isEmpty()) {
            Toast.makeText(this, "스캔된 값이 없습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(() -> {
            try {
                printerHelper.connectNetwork(printerIp, 6101);
                printerHelper.printQrLabel(lastScannedValue, "스캔라벨");
                printerHelper.disconnect();
                runOnUiThread(() -> Toast.makeText(this, "출력 완료", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                Log.e(TAG, "출력 실패", e);
                runOnUiThread(() -> Toast.makeText(this, "출력 실패: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ScanReceiver.setListener(null);
        if (printerHelper != null) {
            printerHelper.disconnect();
        }
    }
}
