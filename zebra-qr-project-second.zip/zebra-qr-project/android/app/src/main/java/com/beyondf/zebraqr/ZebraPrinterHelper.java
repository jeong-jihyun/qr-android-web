package com.beyondf.zebraqr;

import android.util.Log;

import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.Connection;
import com.zebra.sdk.comm.TcpConnection;
import com.zebra.sdk.printer.PrinterLanguage;
import com.zebra.sdk.printer.ZebraPrinter;
import com.zebra.sdk.printer.ZebraPrinterFactory;

/**
 * Zebra Link-OS SDK를 이용한 라벨 프린터 제어 헬퍼.
 *
 * 사전 준비:
 * 1) Zebra 개발자 사이트에서 Link-OS Multi-Platform SDK(Android) 다운로드
 *    https://www.zebra.com/us/en/support-downloads/software/link-os-drivers/link-os-multi-platform-sdk.html
 * 2) 받은 jar를 app/libs/ZSDK_ANDROID_API.jar 로 배치
 * 3) app/build.gradle 의 `implementation files('libs/ZSDK_ANDROID_API.jar')` 주석 해제
 *
 * 연결 방식은 두 가지를 지원한다:
 * - Bluetooth: 프린터의 MAC 주소로 연결 (페어링 필요)
 * - 네트워크(TCP): 프린터 IP:Port(기본 6101)로 연결
 */
public class ZebraPrinterHelper {

    private static final String TAG = "ZebraPrinterHelper";

    private Connection connection;
    private ZebraPrinter printer;

    /** Bluetooth로 프린터에 연결 (예: MAC 주소 "XX:XX:XX:XX:XX:XX") */
    public void connectBluetooth(String macAddress) throws Exception {
        connection = new BluetoothConnection(macAddress);
        connection.open();
        printer = ZebraPrinterFactory.getInstance(PrinterLanguage.ZPL, connection);
        Log.i(TAG, "Bluetooth 프린터 연결 완료: " + macAddress);
    }

    /** 네트워크(TCP)로 프린터에 연결 */
    public void connectNetwork(String ipAddress, int port) throws Exception {
        connection = new TcpConnection(ipAddress, port);
        connection.open();
        printer = ZebraPrinterFactory.getInstance(PrinterLanguage.ZPL, connection);
        Log.i(TAG, "네트워크 프린터 연결 완료: " + ipAddress + ":" + port);
    }

    /** QR코드 라벨 출력 */
    public void printQrLabel(String data, String title) throws Exception {
        String zpl = "^XA\n" +
                "^CI28\n" +
                "^FO50,30^A0N,30,30^FD" + safe(title) + "^FS\n" +
                "^FO50,80^BQN,2,6\n" +
                "^FDQA," + safe(data) + "^FS\n" +
                "^XZ";
        sendRaw(zpl);
    }

    /** 1D 바코드(Code128) 라벨 출력 */
    public void printBarcodeLabel(String data, String title) throws Exception {
        String zpl = "^XA\n" +
                "^CI28\n" +
                "^FO50,30^A0N,30,30^FD" + safe(title) + "^FS\n" +
                "^FO50,80^BCN,100,Y,N,N\n" +
                "^FD" + safe(data) + "^FS\n" +
                "^XZ";
        sendRaw(zpl);
    }

    /** 임의의 ZPL 원시 명령 전송 */
    public void sendRaw(String zpl) throws Exception {
        if (connection == null || !connection.isConnected()) {
            throw new IllegalStateException("프린터가 연결되어 있지 않습니다. connectBluetooth/connectNetwork를 먼저 호출하세요.");
        }
        connection.write(zpl.getBytes("UTF-8"));
    }

    public void disconnect() {
        try {
            if (connection != null && connection.isConnected()) {
                connection.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "연결 종료 실패", e);
        }
    }

    private String safe(String s) {
        return s == null ? "" : s.replace("^", "").replace("~", "");
    }
}
