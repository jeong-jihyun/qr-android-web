package com.beyondf.zebraqr;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Zebra DataWedge가 스캔 결과를 브로드캐스트로 전달할 때 수신하는 리시버.
 *
 * DataWedge 프로필 설정 (Zebra 단말의 DataWedge 앱에서):
 * 1) 새 프로필 생성 후 이 앱(com.beyondf.zebraqr)에 연결
 * 2) Barcode Input 활성화 (원하는 심볼로지: QR Code, Code128 등 체크)
 * 3) Intent Output 활성화
 *    - Intent Action: com.beyondf.zebraqr.SCAN
 *    - Intent Delivery: Broadcast Intent
 */
public class ScanReceiver extends BroadcastReceiver {

    private static final String TAG = "ScanReceiver";

    // DataWedge 기본 extra 키
    private static final String EXTRA_DATA_STRING = "com.symbol.datawedge.data_string";
    private static final String EXTRA_LABEL_TYPE = "com.symbol.datawedge.label_type";

    public interface ScanListener {
        void onScan(String data, String labelType);
    }

    private static ScanListener listener;

    /** MainActivity(또는 화면)에서 스캔 결과를 받고 싶을 때 등록 */
    public static void setListener(ScanListener l) {
        listener = l;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String data = intent.getStringExtra(EXTRA_DATA_STRING);
        String labelType = intent.getStringExtra(EXTRA_LABEL_TYPE);

        if (data == null) {
            Log.w(TAG, "스캔 데이터 없음: " + intent.getExtras());
            return;
        }

        Log.i(TAG, "스캔 수신: " + data + " (타입: " + labelType + ")");

        if (listener != null) {
            listener.onScan(data, labelType);
        }
    }
}
